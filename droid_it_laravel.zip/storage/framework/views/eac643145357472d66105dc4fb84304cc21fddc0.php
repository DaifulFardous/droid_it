

<?php $__env->startSection('content'); ?>
    <header class="header">
        <?php echo $__env->make('landing_pages.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <main>
        <section class="section-contact">
            <div class="contact">
                <div class="contact__form">
                    <div class="contact__form-box">
                        <form>
                            <div class="contact__heading-box">
                                <h1 class="heading-primary">Yes!! we are really excited
                                    to hear about your project</h1>
                            </div>

                            <div class="contact__info-area">
                                <div class="contact__input-box">
                                    <label class="contact__input-label">Full Name</label>
                                    <input class="contact__input" placeholder="Full Name" />
                                </div>
                                <div class="contact__input-box">
                                    <label class="contact__input-label">Full Name</label>
                                    <input class="contact__input" placeholder="Full Name" />
                                </div>
                                <div class="contact__input-box">
                                    <label class="contact__input-label">Full Name</label>
                                    <input class="contact__input" placeholder="Full Name" />
                                </div>
                                <div class="contact__input-box">
                                    <label class="contact__input-label">Full Name</label>
                                    <input class="contact__input" placeholder="Full Name" />
                                </div>
                            </div>

                            <div class="contact__input-box">
                                <label class="contact__input-label">Service you are looking for</label>

                                <div class="contact__service-box">
                                    <div class="contact__service-item">
                                        <a href="#" class="contact__service">Design & Development</a>
                                    </div>
                                    <div class="contact__service-item">
                                        <a href="#" class="contact__service">Design</a>
                                    </div>
                                    <div class="contact__service-item">
                                        <a href="#" class="contact__service">Development</a>
                                    </div>
                                    <div class="contact__service-item">
                                        <a href="#" class="contact__service">Social Media Content</a>
                                    </div>
                                </div>
                            </div>

                            <div class="contact__textarea-box">
                                <div class="contact__input-box">
                                    <label class="contact__input-label">Tell us about your idea</label>

                                    <textarea class="contact__textarea" rows="23">Lorem ipsum dolor sit amet.</textarea>
                                </div>
                            </div>

                            <div class="contact__btn-box">
                                <button class="btn-secondary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="contact__img-box">
                    <img src="<?php echo e(asset('assets/img/contact/contact.png')); ?>" class="contact__img" />
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing_pages.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Work\droid_it_laravel\resources\views/landing_pages/pages/contact.blade.php ENDPATH**/ ?>